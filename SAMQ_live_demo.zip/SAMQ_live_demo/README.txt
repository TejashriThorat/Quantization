SAMQ live demo (Progress Presentation II)
-----------------------------------------
Requirements: Python 3.9+, pip install torch tokenizers scipy numpy
Run:          python demo.py
What it does: loads the FP32 model, quantizes it to 2 bits with GPTQ, loads the
              2-bit SAMQ model (LSQ + KD), evaluates all three on the WikiText-2
              test set and generates text from the same prompt.
Time:         about 3.5 minutes on a 2-core CPU (much faster on a GPU/modern laptop).
Expected:     FP32 53.56 PPL (27.61 MB) | GPTQ 2-bit ~55.0 (3.71 MB) | SAMQ 2-bit 54.04 (3.71 MB)
Note:         to fit the upload limit, weights here are stored in fp16. GPTQ re-quantizes the
              fp16 copy live, so it gives 55.01 instead of the 54.92 on the slides (computed from
              the fp32 weights). FP32 and SAMQ numbers are unchanged.
