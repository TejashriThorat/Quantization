"""packing.py -- real bit-packed export of a quantised model and exact size accounting."""
import numpy as np
import torch

def pack_codes(codes, bits):
    """codes: uint8 array of values in [0, 2^bits). Returns bytes using exactly ceil(N*bits/8) bytes."""
    c = np.asarray(codes, dtype=np.uint8).ravel()
    planes = np.unpackbits(c[:, None], axis=1)[:, 8 - bits:]      # (N, bits), MSB first
    return np.packbits(planes.ravel()).tobytes(), c.size

def unpack_codes(buf, n, bits):
    planes = np.unpackbits(np.frombuffer(buf, dtype=np.uint8))[:n * bits].reshape(n, bits)
    full = np.zeros((n, 8), dtype=np.uint8); full[:, 8 - bits:] = planes
    return np.packbits(full, axis=1).ravel()

@torch.no_grad()
def export_linear(W, s, z, bits, g):
    """Quantise W (out,in) with group params s,z (out, in/g). Returns dict of packed buffers."""
    qmax = 2 ** bits - 1
    s = s.to(torch.float16).to(torch.float32)          # scales are stored in fp16
    o, i = W.shape
    wg = W.reshape(o, i // g, g)
    q = torch.clamp(torch.round(wg / s.unsqueeze(-1)) + z.unsqueeze(-1), 0, qmax).to(torch.uint8)
    codes, n = pack_codes(q.cpu().numpy(), bits)
    zeros, nz = pack_codes(z.to(torch.uint8).cpu().numpy(), bits)
    scales = s.to(torch.float16).cpu().numpy().tobytes()
    return dict(codes=codes, n=n, zeros=zeros, nz=nz, scales=scales, shape=(o, i), bits=bits, g=g)

def dequant_linear(e):
    o, i = e['shape']; g = e['g']; b = e['bits']
    q = unpack_codes(e['codes'], e['n'], b).reshape(o, i // g, g).astype(np.float32)
    z = unpack_codes(e['zeros'], e['nz'], b).reshape(o, i // g, 1).astype(np.float32)
    s = np.frombuffer(e['scales'], dtype=np.float16).reshape(o, i // g, 1).astype(np.float32)
    return torch.from_numpy(((q - z) * s).reshape(o, i))

def nbytes(e):
    return len(e['codes']) + len(e['zeros']) + len(e['scales'])
