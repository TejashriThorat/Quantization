"""
qlib.py -- Sub-4-bit quantization-aware fine-tuning toolkit.

Contents
  * WikiText-2 byte-level BPE data pipeline
  * Pre-LN GPT decoder whose every linear layer is a QLinear (fake-quant capable)
  * Group-wise asymmetric uniform weight quantizer with three modes:
        - 'minmax' : scales recomputed from current weights (STE through round)
        - 'lsq'    : learnable per-group step size and offset (LSQ/LSQ+ style)
        - frozen   : fixed scales (used for PTQ / GPTQ export)
  * MSE-optimal clipping search for scale initialisation
  * GPTQ (Frantar et al., 2023) with group-wise parameters
  * Sensitivity measurement (empirical delta-NLL, Fisher, Hessian-weighted error, kurtosis)
  * Exact ILP bit allocation (scipy.optimize.milp)
  * QAT loop with optional logit distillation, hidden-state distillation and
    progressive bit annealing
"""
import math, os, json, time, copy, random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ----------------------------------------------------------------------------
# Reproducibility
# ----------------------------------------------------------------------------
def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)

# ----------------------------------------------------------------------------
# Data
# ----------------------------------------------------------------------------
def build_data(data_dir, vocab_size=8192, cache='wt2_bpe.pt'):
    path = os.path.join(data_dir, cache)
    if os.path.exists(path):
        return torch.load(path)
    from tokenizers import ByteLevelBPETokenizer
    files = {s: os.path.join(data_dir, f'wt2_{s}.txt') for s in ['train', 'valid', 'test']}
    tok = ByteLevelBPETokenizer()
    tok.train([files['train']], vocab_size=vocab_size, min_frequency=2,
              special_tokens=['<|endoftext|>'])
    out = {}
    for s, f in files.items():
        with open(f, encoding='utf-8') as fh:
            text = fh.read()
        out[s] = torch.tensor(tok.encode(text).ids, dtype=torch.int32)
    out['vocab_size'] = tok.get_vocab_size()
    tok.save_model(data_dir, 'wt2bpe')
    torch.save(out, path)
    return out

def get_batch(data, bs, T, gen=None):
    ix = torch.randint(0, len(data) - T - 1, (bs,), generator=gen)
    x = torch.stack([data[i:i + T] for i in ix]).long()
    y = torch.stack([data[i + 1:i + T + 1] for i in ix]).long()
    return x, y

# ----------------------------------------------------------------------------
# Quantizer
# ----------------------------------------------------------------------------
def round_ste(x):
    return (x.round() - x).detach() + x

def _grouped(w, g):
    """(out, in) -> (out, in/g, g)"""
    o, i = w.shape
    assert i % g == 0, (i, g)
    return w.reshape(o, i // g, g)

@torch.no_grad()
def minmax_params(w, bits, g, alpha=None):
    """Asymmetric per-group scale/zero. alpha: (out, ngroups) shrink ratio for clipping."""
    wg = _grouped(w, g)
    mx = wg.amax(-1); mn = wg.amin(-1)
    if alpha is not None:
        mx = mx * alpha; mn = mn * alpha
    qmax = 2 ** bits - 1
    s = ((mx - mn) / qmax).clamp(min=1e-8)
    z = (-mn / s).round().clamp(0, qmax)
    return s, z

def fake_quant(w, s, z, bits, g, ste=True):
    """Group-wise asymmetric uniform fake quantisation. s, z: (out, ngroups)."""
    qmax = 2 ** bits - 1
    wg = _grouped(w, g)
    s_ = s.unsqueeze(-1); z_ = z.unsqueeze(-1)
    r = round_ste if ste else torch.round
    q = torch.clamp(r(wg / s_) + z_, 0, qmax)
    return ((q - z_) * s_).reshape(w.shape)

@torch.no_grad()
def mse_clip_search(w, bits, g, grid=20, lo=0.5, p=2.0):
    """Per-group grid search of clipping ratio alpha minimising ||w - Q(w)||_p^p."""
    wg = _grouped(w, g)
    best = torch.full(wg.shape[:2], float('inf'))
    best_a = torch.ones(wg.shape[:2])
    for a in torch.linspace(lo, 1.0, grid):
        A = torch.full(wg.shape[:2], float(a))
        s, z = minmax_params(w, bits, g, A)
        err = (fake_quant(w, s, z, bits, g, ste=False) - w).abs().pow(p)
        err = _grouped(err, g).sum(-1)
        m = err < best
        best[m] = err[m]; best_a[m] = float(a)
    return best_a

class QLinear(nn.Linear):
    """nn.Linear with optional group-wise fake quantisation of the weight."""
    def __init__(self, i, o, bias=True):
        super().__init__(i, o, bias)
        self.qmode = None      # None | 'minmax' | 'lsq' | 'frozen'
        self.bits = 16
        self.g = 64
        self.name = ''

    def configure(self, bits, mode, g=64, clip='mse'):
        if g == 0: g = self.weight.shape[1]          # g=0 -> per-output-channel
        self.bits, self.qmode, self.g, self.clip = bits, mode, g, clip
        if mode is None or bits >= 16:
            self.qmode = None; return
        w = self.weight.data
        alpha = mse_clip_search(w, bits, g) if clip == 'mse' else None
        s, z = minmax_params(w, bits, g, alpha)
        if mode == 'lsq':
            # learn log-step and continuous zero point (rounded with STE in fwd)
            self.log_s = nn.Parameter(s.log().clone())
            self.zp = nn.Parameter(z.clone())
        else:
            self.register_buffer('s_buf', s.clone(), persistent=False)
            self.register_buffer('z_buf', z.clone(), persistent=False)
        self.alpha = alpha

    def rebits(self, bits, clip=None):
        """Change bit-width in place (progressive annealing), re-initialising scales."""
        mode = self.qmode
        for n in ['log_s', 'zp']:
            if hasattr(self, n): delattr(self, n)
        for n in ['s_buf', 'z_buf']:
            if n in self._buffers: del self._buffers[n]
        self.configure(bits, mode, self.g, clip or self.clip)

    def qweight(self):
        if self.qmode is None:
            return self.weight
        if self.qmode == 'minmax':
            s, z = minmax_params(self.weight, self.bits, self.g, self.alpha)
            return fake_quant(self.weight, s, z, self.bits, self.g)
        if self.qmode == 'lsq':
            qmax = 2 ** self.bits - 1
            s = self.log_s.exp()
            z = torch.clamp(round_ste(self.zp), 0, qmax)
            return fake_quant(self.weight, s, z, self.bits, self.g)
        if self.qmode == 'frozen':
            return fake_quant(self.weight, self.s_buf, self.z_buf, self.bits, self.g, ste=False)

    def forward(self, x):
        return F.linear(x, self.qweight(), self.bias)

# ----------------------------------------------------------------------------
# Model
# ----------------------------------------------------------------------------
class Block(nn.Module):
    def __init__(self, d, h, ff, drop):
        super().__init__()
        self.h = h
        self.ln1 = nn.LayerNorm(d); self.ln2 = nn.LayerNorm(d)
        self.q = QLinear(d, d); self.k = QLinear(d, d); self.v = QLinear(d, d)
        self.o = QLinear(d, d)
        self.fc1 = QLinear(d, ff); self.fc2 = QLinear(ff, d)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        B, T, C = x.shape
        a = self.ln1(x)
        q = self.q(a).view(B, T, self.h, -1).transpose(1, 2)
        k = self.k(a).view(B, T, self.h, -1).transpose(1, 2)
        v = self.v(a).view(B, T, self.h, -1).transpose(1, 2)
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True,
                                           dropout_p=self.drop.p if self.training else 0.0)
        y = y.transpose(1, 2).reshape(B, T, C)
        x = x + self.drop(self.o(y))
        x = x + self.drop(self.fc2(F.gelu(self.fc1(self.ln2(x)))))
        return x

class GPT(nn.Module):
    def __init__(self, vocab, d=256, L=6, h=4, ff=1024, T=256, drop=0.1):
        super().__init__()
        self.cfg = dict(vocab=vocab, d=d, L=L, h=h, ff=ff, T=T, drop=drop)
        self.wte = nn.Embedding(vocab, d)
        self.wpe = nn.Embedding(T, d)
        self.blocks = nn.ModuleList([Block(d, h, ff, drop) for _ in range(L)])
        self.lnf = nn.LayerNorm(d)
        self.drop = nn.Dropout(drop)
        self.apply(self._init)
        for b in self.blocks:   # GPT-2 residual scaling
            nn.init.normal_(b.o.weight, 0, 0.02 / math.sqrt(2 * L))
            nn.init.normal_(b.fc2.weight, 0, 0.02 / math.sqrt(2 * L))
        for li, b in enumerate(self.blocks):
            for n in ['q', 'k', 'v', 'o', 'fc1', 'fc2']:
                getattr(b, n).name = f'{li}.{n}'

    @staticmethod
    def _init(m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, 0, 0.02)
            if m.bias is not None: nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, 0, 0.02)

    def forward(self, idx, return_hidden=False):
        B, T = idx.shape
        x = self.drop(self.wte(idx) + self.wpe(torch.arange(T)))
        hs = []
        for b in self.blocks:
            x = b(x)
            if return_hidden: hs.append(x)
        x = self.lnf(x)
        logits = x @ self.wte.weight.t()          # tied LM head
        return (logits, hs) if return_hidden else logits

    def qlinears(self):
        return [m for m in self.modules() if isinstance(m, QLinear)]

def nparams(model, linear_only=False):
    if linear_only:
        return sum(m.weight.numel() for m in model.qlinears())
    return sum(p.numel() for p in model.parameters())

# ----------------------------------------------------------------------------
# Evaluation
# ----------------------------------------------------------------------------
@torch.no_grad()
def evaluate(model, data, T=256, max_windows=None, bs=16):
    """Perplexity with non-overlapping windows; also top-1 next-token accuracy."""
    model.eval()
    n = (len(data) - 1) // T
    if max_windows: n = min(n, max_windows)
    nll, cnt, correct = 0.0, 0, 0
    for i in range(0, n, bs):
        idx = torch.arange(i, min(i + bs, n)) * T
        x = torch.stack([data[j:j + T] for j in idx]).long()
        y = torch.stack([data[j + 1:j + T + 1] for j in idx]).long()
        lg = model(x)
        nll += F.cross_entropy(lg.reshape(-1, lg.size(-1)), y.reshape(-1), reduction='sum').item()
        correct += (lg.argmax(-1) == y).sum().item()
        cnt += y.numel()
    return dict(ppl=math.exp(nll / cnt), nll=nll / cnt, acc=correct / cnt)

# ----------------------------------------------------------------------------
# Quantisation configuration helpers
# ----------------------------------------------------------------------------
def quantize_model(model, bits_map, mode, g=64, clip='mse'):
    """bits_map: dict layer-name -> bits, or an int for uniform."""
    for m in model.qlinears():
        b = bits_map if isinstance(bits_map, int) else bits_map.get(m.name, 16)
        m.configure(b, mode, g, clip)
    return model

def bake(model):
    """Replace weights by their quantised values and drop the quantiser (export)."""
    with torch.no_grad():
        for m in model.qlinears():
            if m.qmode is not None:
                m.weight.data = m.qweight().detach().clone()
                m.qmode = None
    return model

def bits_report(model, g=64, scale_bits=16):
    """Average weight bits over quantised linears incl. per-group scale+zero overhead."""
    tot, bits_sum, eff = 0, 0, 0
    for m in model.qlinears():
        n = m.weight.numel(); tot += n
        b = m.bits if m.qmode is not None else 16
        bits_sum += b * n
        over = (scale_bits + b) / m.g if b < 16 else 0   # fp16 scale + b-bit zero per group
        eff += (b + over) * n
    return dict(avg_bits=bits_sum / tot, eff_bits=eff / tot)

# ----------------------------------------------------------------------------
# GPTQ
# ----------------------------------------------------------------------------
@torch.no_grad()
def collect_inputs(model, calib, layer_names=None):
    """Return H = 2 X^T X / N for every QLinear's input on calibration batches."""
    Hs, cnt, hooks = {}, {}, []
    for m in model.qlinears():
        if layer_names and m.name not in layer_names: continue
        def hook(mod, inp, out):
            x = inp[0].reshape(-1, inp[0].shape[-1]).double()
            Hs[mod.name] = Hs.get(mod.name, 0) + 2 * x.t() @ x
            cnt[mod.name] = cnt.get(mod.name, 0) + x.shape[0]
        hooks.append(m.register_forward_hook(hook))
    model.eval()
    for x in calib: model(x)
    for h in hooks: h.remove()
    return {k: (v / cnt[k]).float() for k, v in Hs.items()}

@torch.no_grad()
def gptq_layer(W, H, bits, g, blocksize=128, percdamp=0.01, clip='mse', actorder=False):
    W = W.clone().float(); ncol = W.shape[1]
    H = H.clone()
    dead = torch.diag(H) == 0
    H[dead, dead] = 1; W[:, dead] = 0
    perm = None
    if actorder:
        perm = torch.argsort(torch.diag(H), descending=True)
        W = W[:, perm]; H = H[perm][:, perm]
    damp = percdamp * torch.mean(torch.diag(H))
    H += damp * torch.eye(ncol)
    Hinv = torch.linalg.cholesky(torch.cholesky_inverse(torch.linalg.cholesky(H)), upper=True)
    Q = torch.zeros_like(W)
    qmax = 2 ** bits - 1
    s = z = None
    for i1 in range(0, ncol, blocksize):
        i2 = min(i1 + blocksize, ncol)
        W1 = W[:, i1:i2].clone(); Q1 = torch.zeros_like(W1); Err1 = torch.zeros_like(W1)
        Hinv1 = Hinv[i1:i2, i1:i2]
        for i in range(i2 - i1):
            col = i1 + i
            if col % g == 0:
                blk = W[:, col:col + g].clone()
                blk[:, :min(g, i2 - col)] = W1[:, i:i + min(g, i2 - col)]
                if col + g > i2:   # group straddles block: use updated tail where known
                    blk[:, i2 - col:] = W[:, i2:col + g]
                alpha = mse_clip_search(blk, bits, g).squeeze(1) if clip == 'mse' else None
                mx = blk.amax(1); mn = blk.amin(1)
                if alpha is not None: mx, mn = mx * alpha, mn * alpha
                s = ((mx - mn) / qmax).clamp(min=1e-8); z = (-mn / s).round().clamp(0, qmax)
            w = W1[:, i]; d = Hinv1[i, i]
            q = (torch.clamp(torch.round(w / s) + z, 0, qmax) - z) * s
            Q1[:, i] = q
            err = (w - q) / d
            W1[:, i:] -= err.unsqueeze(1) @ Hinv1[i, i:].unsqueeze(0)
            Err1[:, i] = err
        Q[:, i1:i2] = Q1
        W[:, i2:] -= Err1 @ Hinv[i1:i2, i2:]
    if perm is not None:
        Q = Q[:, torch.argsort(perm)]
    return Q

@torch.no_grad()
def gptq_quantize(model, calib, bits_map, g=64, clip='mse'):
    """Sequential, block-by-block GPTQ with 'true-sequential' sub-groups: inputs of a
    sub-layer are produced by the already-quantised preceding sub-layers and blocks."""
    model.eval()
    xs = []
    for x in calib:
        T = x.shape[1]
        xs.append(model.wte(x) + model.wpe(torch.arange(T)))
    for li, blk in enumerate(model.blocks):
        for grp in [['q', 'k', 'v'], ['o'], ['fc1'], ['fc2']]:
            Hs, cnt, hooks = {}, {}, []
            for n in grp:
                mod = getattr(blk, n)
                def hook(mod, inp, out):
                    a = inp[0].reshape(-1, inp[0].shape[-1]).double()
                    Hs[mod.name] = Hs.get(mod.name, 0) + 2 * a.t() @ a
                    cnt[mod.name] = cnt.get(mod.name, 0) + a.shape[0]
                hooks.append(mod.register_forward_hook(hook))
            for h in xs: blk(h)
            for h in hooks: h.remove()
            for n in grp:
                m = getattr(blk, n)
                b = bits_map if isinstance(bits_map, int) else bits_map.get(m.name, 16)
                if b >= 16: continue
                gg = g if g else m.weight.shape[1]
                m.weight.data = gptq_layer(m.weight.data, (Hs[m.name] / cnt[m.name]).float(), b, gg, clip=clip)
        xs = [blk(h) for h in xs]
    return model

# ----------------------------------------------------------------------------
# Sensitivity
# ----------------------------------------------------------------------------
def kurtosis(w):
    w = w.flatten().double(); m = w.mean(); v = ((w - m) ** 2).mean()
    return (((w - m) ** 4).mean() / v ** 2).item()

def empirical_fisher(model, data, nb=16, bs=8, T=256, seed=0):
    """Diagonal empirical Fisher (mean squared gradient) for every QLinear weight."""
    g = torch.Generator().manual_seed(seed)
    model.eval()
    fis = {m.name: torch.zeros_like(m.weight) for m in model.qlinears()}
    for _ in range(nb):
        x, y = get_batch(data, bs, T, g)
        model.zero_grad()
        lg = model(x)
        F.cross_entropy(lg.reshape(-1, lg.size(-1)), y.reshape(-1)).backward()
        for m in model.qlinears():
            fis[m.name] += m.weight.grad.detach() ** 2 / nb
    model.zero_grad()
    return fis

# ----------------------------------------------------------------------------
# ILP bit allocation
# ----------------------------------------------------------------------------
def allocate_bits(cost, sizes, choices, budget_avg, fixed=None):
    """min sum_l cost[l][b] x_lb  s.t. sum_b x_lb = 1, sum_lb size_l b x_lb <= budget_avg*sum size.
    cost: dict name -> dict bits -> value. Solved exactly with scipy MILP (HiGHS)."""
    from scipy.optimize import milp, LinearConstraint, Bounds
    names = list(cost.keys()); L = len(names); K = len(choices)
    c = np.array([cost[n][b] for n in names for b in choices], dtype=float)
    A_one = np.zeros((L, L * K))
    for i in range(L): A_one[i, i * K:(i + 1) * K] = 1
    tot = sum(sizes[n] for n in names)
    A_bud = np.array([[sizes[n] * b for n in names for b in choices]], dtype=float) / tot
    cons = [LinearConstraint(A_one, 1, 1), LinearConstraint(A_bud, -np.inf, budget_avg + 1e-9)]
    res = milp(c, constraints=cons, integrality=np.ones(L * K), bounds=Bounds(0, 1))
    assert res.success, res.message
    x = res.x.reshape(L, K).round()
    return {n: choices[int(x[i].argmax())] for i, n in enumerate(names)}

# ----------------------------------------------------------------------------
# QAT
# ----------------------------------------------------------------------------
def qat_train(student, train, valid, steps=600, bs=16, T=256, lr=2e-4, qlr=1e-3,
              teacher=None, kd='logit', kd_T=1.0, hid_w=0.0, anneal=None, seed=0,
              log_every=100, eval_windows=64, warmup=30, verbose=True):
    """Quantisation-aware fine-tuning.
    kd: None (CE only) | 'logit' (KL to teacher) | 'mix' (0.5 CE + 0.5 KL)
    hid_w: weight on per-block hidden-state MSE distillation
    anneal: None or dict(final=bits_map, start_bits=4, frac=0.5) progressive bit lowering
    """
    set_seed(seed)
    gen = torch.Generator().manual_seed(seed)
    student.train()
    if teacher is not None: teacher.eval()

    def make_opt():
        wp = [p for n, p in student.named_parameters() if not (n.endswith('log_s') or n.endswith('zp'))]
        qp = [p for n, p in student.named_parameters() if (n.endswith('log_s') or n.endswith('zp'))]
        groups = [{'params': wp, 'lr': lr, 'weight_decay': 0.0}]
        if qp: groups.append({'params': qp, 'lr': qlr, 'weight_decay': 0.0})
        return torch.optim.AdamW(groups, betas=(0.9, 0.95))
    opt = make_opt()
    base = [gr['lr'] for gr in opt.param_groups]

    # progressive annealing schedule: each layer moves start_bits -> target in stages
    stages = []
    if anneal:
        final = anneal['final']; sb = anneal.get('start_bits', 4)
        mids = sorted({b for b in range(min(final.values()), sb)}, reverse=True)  # e.g. [3,2]
        n_st = len(mids)
        for k, b in enumerate(mids):
            at = int(anneal.get('frac', 0.5) * steps * (k + 1) / (n_st + 1))
            stages.append((at, b))
    hist = []
    t0 = time.time()
    for step in range(steps):
        for at, b in stages:
            if step == at:
                for m in student.qlinears():
                    tgt = anneal['final'].get(m.name, 16)
                    if m.qmode is not None and m.bits > max(b, tgt):
                        m.rebits(max(b, tgt))
                opt = make_opt()
        frac = step / steps
        mult = min(1.0, (step + 1) / warmup) * 0.5 * (1 + math.cos(math.pi * frac))
        for gr, b0 in zip(opt.param_groups, base): gr['lr'] = b0 * mult
        x, y = get_batch(train, bs, T, gen)
        if hid_w > 0:
            lg, hs = student(x, return_hidden=True)
        else:
            lg = student(x)
        ce = F.cross_entropy(lg.reshape(-1, lg.size(-1)), y.reshape(-1))
        loss = ce
        if teacher is not None and kd:
            with torch.no_grad():
                if hid_w > 0: tl, ths = teacher(x, return_hidden=True)
                else: tl = teacher(x)
            kl = F.kl_div(F.log_softmax(lg / kd_T, -1), F.log_softmax(tl / kd_T, -1),
                          log_target=True, reduction='none').sum(-1).mean() * kd_T ** 2
            loss = kl if kd == 'logit' else 0.5 * ce + 0.5 * kl
            if hid_w > 0:
                hl = sum(F.mse_loss(a, b) / b.pow(2).mean() for a, b in zip(hs, ths)) / len(hs)
                loss = loss + hid_w * hl
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(student.parameters(), 1.0)
        opt.step()
        if (step + 1) % log_every == 0 or step == steps - 1:
            ev = evaluate(student, valid, T, max_windows=eval_windows)
            student.train()
            hist.append(dict(step=step + 1, loss=loss.item(), ce=ce.item(), val_ppl=ev['ppl'],
                             t=time.time() - t0))
            if verbose:
                print(f'  step {step+1:5d} loss {loss.item():.4f} ce {ce.item():.4f} '
                      f'val_ppl {ev["ppl"]:.2f} ({time.time()-t0:.0f}s)', flush=True)
    student.eval()
    return hist
