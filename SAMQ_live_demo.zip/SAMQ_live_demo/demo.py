"""Live demo: FP32 vs. 2-bit models side by side (perplexity, size, generated text).
usage: python3 demo.py
"""
import os, sys, time, torch, torch.nn.functional as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); os.chdir(os.path.dirname(os.path.abspath(__file__)))
from qlib import *
from packing import export_linear, nbytes
from tokenizers import ByteLevelBPETokenizer
torch.set_num_threads(2)

D = {k: (v.to(torch.int32) if torch.is_tensor(v) else v) for k, v in torch.load('data/wt2_bpe_int16.pt').items()}
tok = ByteLevelBPETokenizer('data/wt2bpe-vocab.json', 'data/wt2bpe-merges.txt')
ck = torch.load('ckpt/fp_base_fp16.pt')
ck['sd'] = {k: v.float() for k, v in ck['sd'].items()}

def fresh():
    m = GPT(**ck['cfg']); m.load_state_dict(ck['sd']); m.eval(); return m

def emb8(m):
    w = m.wte.weight.data
    s, z = minmax_params(w, 8, 64, mse_clip_search(w, 8, 64))
    m.wte.weight.data = fake_quant(w, s, z, 8, 64, ste=False)

def packed_mb(m, bits):
    tot = 0
    for q in m.qlinears():
        W = q.weight.data
        s, z = minmax_params(W, bits, 64, mse_clip_search(W, bits, 64))
        tot += nbytes(export_linear(W, s, z, bits, 64))
    W = m.wte.weight.data; s, z = minmax_params(W, 8, 64)
    tot += nbytes(export_linear(W, s, z, 8, 64))
    tot += 2 * sum(p.numel() for n, p in m.named_parameters() if p.dim() < 2 or 'wpe' in n)
    return tot / 1e6

@torch.no_grad()
def generate(m, prompt, n=28, k=8, temp=0.8, seed=0):
    g = torch.Generator().manual_seed(seed)
    ids = tok.encode(prompt).ids
    x = torch.tensor([ids])
    for _ in range(n):
        lg = m(x[:, -256:])[0, -1] / temp
        v, i = torch.topk(lg, k)
        nxt = i[torch.multinomial(F.softmax(v, -1), 1, generator=g)]
        x = torch.cat([x, nxt.view(1, 1)], 1)
    return tok.decode(x[0].tolist())

PROMPT = ' The game was released in'
print('=' * 72)
print('SAMQ live demo | WikiText-2 test set (323k tokens)')
print('=' * 72)
models = {}
fp = fresh(); models['FP32 (baseline)'] = (fp, 32)
g = torch.Generator().manual_seed(123)
calib = [get_batch(D['train'], 16, 256, g)[0] for _ in range(8)]
t0 = time.time(); gq = fresh(); gptq_quantize(gq, calib, 2, 64); emb8(gq)
print(f'[GPTQ 2-bit] quantized in {time.time()-t0:.0f}s')
models['GPTQ 2-bit (PTQ)'] = (gq, 2)
sq = torch.load('ckpt/samq_w2_fp16.pt')
st = GPT(**sq['cfg']); st.load_state_dict({k: v.float() for k, v in sq['sd'].items()}); st.eval(); emb8(st)
models['SAMQ 2-bit (QAT+KD)'] = (st, 2)
print(f'{"Model":24s} {"Test PPL":>9s} {"Top-1 acc":>10s} {"Size (MB)":>10s}')
for name, (m, b) in models.items():
    r = evaluate(m, D['test'], 256)
    size = 4 * nparams(fresh()) / 1e6 if b == 32 else packed_mb(m, b)
    print(f'{name:24s} {r["ppl"]:9.2f} {100*r["acc"]:9.2f}% {size:10.2f}')
print('-' * 72)
print(f'Prompt: "{PROMPT.strip()}"')
for name, (m, b) in models.items():
    print(f'{name:24s}: {generate(m, PROMPT).strip()!r}')
